package com.example.SpringBootProdCrud.service;

public interface ProductService {

}
