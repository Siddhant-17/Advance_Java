package com.example.SpringBootRESTWebService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
