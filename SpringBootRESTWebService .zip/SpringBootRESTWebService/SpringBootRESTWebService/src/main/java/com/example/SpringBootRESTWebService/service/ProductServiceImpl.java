package com.example.SpringBootRESTWebService.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringBootRESTWebService.dao.ProductDao;
import com.example.SpringBootRESTWebService.model.Product;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductDao productdao;

	@Override
	public List<Product> getallProducts() {
		System.out.println("count : "+productdao.count());
		return productdao.findAll();
	}

	@Override
	public Product getById(int id) {
		Optional<Product> op= productdao.findById(id);
		if(op.isPresent())
		return op.get();
		else 
			return null;
	}

	@Override
	public void addProduct(Product p) {
		productdao.save(p);
		
	}

	@Override
	public void delete(int pid) {
		productdao.deleteById(pid);
		
	}

	@Override
	public void updateById(Product p) {
		Optional<Product> op=productdao.findById(p.getPid());
		if(op.isPresent())
		{
			Product p2=op.get();
			p2.setPname(p.getPname());
			p2.setPrice(p.getPrice());
			p2.setQty(p.getQty());
			productdao.save(p2);
		}
	}

	@Override
	public List<Product> getProductByPrice(int lpr, int hpr) {
		
		return productdao.getProductByPrice(lpr,hpr);
	}
	
	
	

}
