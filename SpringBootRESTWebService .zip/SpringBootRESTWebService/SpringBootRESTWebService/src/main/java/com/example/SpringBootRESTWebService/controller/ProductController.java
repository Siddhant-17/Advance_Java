package com.example.SpringBootRESTWebService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringBootRESTWebService.model.Product;
import com.example.SpringBootRESTWebService.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private ProductService productservice;
	
	
	@GetMapping("/products")
	public List<Product> getallProducts()
	{
		List<Product> plist=productservice.getallProducts();
		if(plist ==null)
			System.out.println("not found");
		System.out.println(plist);
		return plist;
	}
	
	@GetMapping("/products/{pid}")
	public ResponseEntity<Product> getById(@PathVariable("pid") int id)
	{
		Product p=productservice.getById(id);
		if(p!=null)
			return ResponseEntity.ok(p);
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		
	}
	
	@PostMapping("/products/{pid}")
	public ResponseEntity<String>  addproduct(@RequestBody Product p)
	{
		productservice.addProduct(p);
		return ResponseEntity.ok("added");
		
	}

	@DeleteMapping("/products/{pid}")
	public  ResponseEntity<String> deleteProduct(@PathVariable int pid) {
		
		productservice.delete(pid);
		return ResponseEntity.ok("deleted");
		
	}
	
	@PutMapping("/products/{pid}")
	public ResponseEntity<String> updateproduct(@RequestBody Product p)
	{
		productservice.updateById(p);
		return ResponseEntity.ok("updated");
	
	}
	
	@GetMapping("/products/price/{lpr}/{hpr}")
	public ResponseEntity<List<Product>> getProductByPrice(@PathVariable int lpr,@PathVariable int hpr)
	{
		List<Product> plist=productservice.getProductByPrice(lpr,hpr);
		
		return ResponseEntity.ok(plist);
		
	}
	
}
