package com.example.SpringBootRESTWebService.service;

import java.util.List;

import com.example.SpringBootRESTWebService.model.Product;

public interface ProductService {

	List<Product> getallProducts();

	Product getById(int id);

	void addProduct(Product p);

	void delete(int pid);

	void updateById(Product p);

	List<Product> getProductByPrice(int lpr, int hpr);

}
